package task;

// Перечисление TaskType определяет типы задач в системе
public enum TaskType {
    TASK,
    EPIC,
    SUBTASK
}
