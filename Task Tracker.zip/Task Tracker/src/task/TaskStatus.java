package task;

// Перечисление TaskStatus определяет возможные статусы задачи
public enum TaskStatus {
    NEW,
    IN_PROGRESS,
    DONE
}